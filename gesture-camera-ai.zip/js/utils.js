// ============================================================
// utils.js — دوال مساعدة عامة يُعاد استخدامها في عدّة وحدات
// ============================================================
import { dom } from './dom.js';
import { state } from './state.js';

export function dist2D(a, b){
  return Math.hypot(a.x - b.x, a.y - b.y);
}

// يحوّل إحداثيات مُطبَّعة (0-1) من إطار الفيديو الأصلي إلى بكسل ضمن
// حاوية العرض، مع مراعاة الاقتصاص الناتج عن object-fit:cover
export function mapNormToDisplay(nx, ny, videoW, videoH, dispW, dispH){
  const scale = Math.max(dispW / videoW, dispH / videoH);
  const scaledW = videoW * scale, scaledH = videoH * scale;
  const offsetX = (scaledW - dispW) / 2, offsetY = (scaledH - dispH) / 2;
  return { x: nx * scaledW - offsetX, y: ny * scaledH - offsetY };
}

// نسخة "واعية بالمرآة" — تُستخدم دائمًا عند تحويل نقطة على اليد إلى
// مكان مرئي على الشاشة (سواء للرسم على القنوات أو لتموضع المؤشر).
// القنوات (canvas) لا تحمل أي تحويل CSS خاص بها؛ الانعكاس يُحسب هنا
// يدويًا حتى لا يحدث انعكاس مزدوج مع عنصر الفيديو
export function getDisplayPoint(nx, ny, rect){
  const d = mapNormToDisplay(nx, ny, dom.video.videoWidth, dom.video.videoHeight, rect.width, rect.height);
  const mirror = state.settings.mirror && state.facingMode === 'user';
  return { x: mirror ? (rect.width - d.x) : d.x, y: d.y };
}

// نفس الفكرة لكن للمُدخل بالبكسل الفعلي (يُستخدم لصناديق كاشف الأشياء)
export function mapVideoPxToDisplay(px, py, videoW, videoH, dispW, dispH){
  return mapNormToDisplay(px / videoW, py / videoH, videoW, videoH, dispW, dispH);
}

export const safeStorage = {
  get(k){ try{ return localStorage.getItem(k); }catch(e){ return null; } },
  set(k, v){ try{ localStorage.setItem(k, v); }catch(e){} }
};

let toastTimer = null;
export function showToast(msg){
  dom.toast.textContent = msg;
  dom.toast.classList.add('show');
  clearTimeout(toastTimer);
  toastTimer = setTimeout(()=> dom.toast.classList.remove('show'), 1800);
}

export function vibrate(ms){
  if (navigator.vibrate){ try{ navigator.vibrate(ms); }catch(e){} }
}

export function isAnyModalOpen(){
  return !dom.helpModal.classList.contains('hidden')
      || !dom.settingsModal.classList.contains('hidden')
      || !dom.galleryModal.classList.contains('hidden')
      || !dom.logModal.classList.contains('hidden');
}

export function formatTime(ts){
  const d = new Date(ts);
  return d.toLocaleTimeString('ar', { hour:'2-digit', minute:'2-digit' });
}
