// ============================================================
// gallery.js — معرض الصور/الرسومات الملتقطة: عرض، حذف، تنزيل،
// وحفظ خفيف في localStorage (يُقتصر على آخر 10 عناصر لتفادي تجاوز الحصّة)
// ============================================================
import { dom } from './dom.js';
import { state } from './state.js';
import { safeStorage } from './utils.js';

const STORAGE_KEY = 'gc_gallery';

export function addToGallery(url, kind){
  state.gallery.unshift({ id: Date.now() + '_' + Math.random().toString(36).slice(2), url, kind });
  renderGallery();
  safeStorage.set(STORAGE_KEY, JSON.stringify(state.gallery.slice(0, 10)));
}

export function loadGalleryFromStorage(){
  const raw = safeStorage.get(STORAGE_KEY);
  if (!raw) return;
  try{
    state.gallery = JSON.parse(raw) || [];
    renderGallery();
  }catch(e){ /* تجاهل بيانات تالفة */ }
}

export function renderGallery(){
  if (!state.gallery.length){
    dom.galleryGrid.innerHTML = '<div id="galleryEmpty">لا توجد صور بعد.<br>أشِر بعلامة ✌️ لالتقاط أول صورة.</div>';
    return;
  }
  dom.galleryGrid.innerHTML = state.gallery.map(item => `
    <div class="gallery-item">
      <img src="${item.url}" alt="">
      <span class="g-kind">${item.kind === 'photo' ? '📸' : (item.kind === 'drawing' ? '🎨' : '🔍')}</span>
      <button class="g-del" data-action="del" data-id="${item.id}">✕</button>
      <button class="g-dl" data-action="dl" data-id="${item.id}">⬇️</button>
    </div>`).join('');
}

export function initGalleryEvents(){
  dom.galleryGrid.addEventListener('click', (e)=>{
    const btn = e.target.closest('button[data-action]');
    if (!btn) return;
    const item = state.gallery.find(g => String(g.id) === String(btn.dataset.id));
    if (!item) return;

    if (btn.dataset.action === 'del'){
      state.gallery = state.gallery.filter(g => g !== item);
      renderGallery();
      safeStorage.set(STORAGE_KEY, JSON.stringify(state.gallery.slice(0, 10)));
    } else if (btn.dataset.action === 'dl'){
      const a = document.createElement('a');
      a.href = item.url;
      const ext = item.kind === 'drawing' ? '.png' : '.jpg';
      const prefix = item.kind === 'photo' ? 'صورة-' : (item.kind === 'drawing' ? 'رسمة-' : 'تعرف-');
      a.download = prefix + item.id + ext;
      document.body.appendChild(a); a.click(); document.body.removeChild(a);
    }
  });
}
