// ============================================================
// camera.js — إدارة تدفّق الكاميرا (getUserMedia) والتبديل بينها
// ============================================================
import { dom } from './dom.js';
import { state } from './state.js';

export async function startCamera(nextFacing){
  if (state.stream){
    state.stream.getTracks().forEach(t => t.stop());
  }
  const constraints = {
    video: { facingMode: nextFacing, width:{ideal:1280}, height:{ideal:720} },
    audio: false
  };
  state.stream = await navigator.mediaDevices.getUserMedia(constraints);
  dom.video.srcObject = state.stream;
  state.facingMode = nextFacing;

  await new Promise(resolve=>{
    if (dom.video.readyState >= 2) return resolve();
    dom.video.onloadedmetadata = () => resolve();
  });
  await dom.video.play();
  applyMirrorClass();
}

export function applyMirrorClass(){
  const shouldMirror = state.settings.mirror && state.facingMode === 'user';
  dom.videoContainer.classList.toggle('no-mirror', !shouldMirror);
}
