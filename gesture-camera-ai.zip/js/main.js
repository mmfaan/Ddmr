// ============================================================
// main.js — نقطة الدخول: يُشغَّل تلقائيًا لأنه مرتبط بوسم
// <script type="module" src="js/main.js"> في index.html
// ============================================================
import { FilesetResolver } from "https://cdn.jsdelivr.net/npm/@mediapipe/tasks-vision@0.10.14";
import { dom } from './dom.js';
import { state } from './state.js';
import { MODEL_URLS } from './config.js';
import { safeStorage } from './utils.js';
import { startCamera } from './camera.js';
import { initHandLandmarker } from './handTracking.js';
import { initObjectDetector } from './objectDetection.js';
import { redrawDrawCanvas } from './drawing.js';
import { initUI, setMode } from './ui.js';
import { initGalleryEvents, loadGalleryFromStorage } from './gallery.js';
import { startEngine, stopEngine } from './engine.js';

function resizeCanvases(){
  const rect = dom.videoContainer.getBoundingClientRect();
  const dpr = Math.min(window.devicePixelRatio || 1, 2);
  [dom.skeletonCanvas, dom.detectionCanvas, dom.drawCanvas].forEach(c=>{
    c.width = Math.round(rect.width * dpr);
    c.height = Math.round(rect.height * dpr);
    c.style.width = rect.width + 'px';
    c.style.height = rect.height + 'px';
    c.getContext('2d').setTransform(dpr, 0, 0, dpr, 0, 0);
  });
  redrawDrawCanvas();
}
window.addEventListener('resize', resizeCanvases);
window.addEventListener('orientationchange', ()=> setTimeout(resizeCanvases, 250));

function showError(err){
  let title = 'تعذّر التشغيل';
  let msg = 'حدث خطأ غير متوقع. تأكد من اتصالك بالإنترنت وأعد المحاولة.';
  const name = err && err.name;
  if (name === 'NotAllowedError' || name === 'PermissionDeniedError'){
    title = 'تم رفض إذن الكاميرا';
    msg = 'فعّل إذن الكاميرا لهذا الموقع من إعدادات المتصفح، ثم أعد تحميل الصفحة.';
  } else if (name === 'NotFoundError' || name === 'DevicesNotFoundError'){
    title = 'لا توجد كاميرا';
    msg = 'لم يتم العثور على كاميرا متاحة على هذا الجهاز.';
  } else if (name === 'NotReadableError'){
    title = 'الكاميرا مشغولة';
    msg = 'الكاميرا قيد الاستخدام من تطبيق آخر. أغلق التطبيقات الأخرى وأعد المحاولة.';
  }
  dom.errorTitle.textContent = title;
  dom.errorText.textContent = msg;
  dom.errorOverlay.classList.remove('hidden');
}

async function boot(){
  dom.introScreen.classList.add('hidden');
  dom.loadingScreen.classList.remove('hidden');
  try{
    dom.loadingText.textContent = 'جارٍ تشغيل الكاميرا…';
    await startCamera(state.facingMode);

    dom.loadingText.textContent = 'جارٍ تحميل نماذج الذكاء الاصطناعي…';
    const vision = await FilesetResolver.forVisionTasks(MODEL_URLS.wasm);
    await initHandLandmarker(vision);
    await initObjectDetector(vision); // فشل هذا النموذج تحديدًا لا يوقف التطبيق (يُعطَّل وضع "تعرّف" فقط)

    resizeCanvases();
    loadGalleryFromStorage();

    dom.loadingScreen.classList.add('hidden');
    dom.app.classList.remove('hidden');
    setMode('photo');
    startEngine();

    if (!safeStorage.get('gc_seen_help')){
      setTimeout(()=>{
        document.getElementById('helpModal').classList.remove('hidden');
        safeStorage.set('gc_seen_help', '1');
      }, 500);
    }
  }catch(err){
    console.error(err);
    dom.loadingScreen.classList.add('hidden');
    showError(err);
  }
}

dom.startBtn.addEventListener('click', boot);
dom.retryBtn.addEventListener('click', ()=>{
  dom.errorOverlay.classList.add('hidden');
  boot();
});

document.addEventListener('visibilitychange', ()=>{
  if (document.hidden){ stopEngine(); }
  else if (state.handLandmarker && !dom.app.classList.contains('hidden')){ startEngine(); }
});

initUI();
initGalleryEvents();
