// ============================================================
// drawing.js — الرسم بالهواء: تخزين الخطوط كنقاط مُطبَّعة (0-1)
// نسبةً لحاوية العرض، بحيث يمكن إعادة رسمها بصحة عند تغيّر الحجم
// ============================================================
import { dom } from './dom.js';
import { state } from './state.js';
import { showToast } from './utils.js';

const MAX_STROKES = 250;

export function startStroke(nx, ny){
  state.currentStroke = { color: state.brushColor, size: state.settings.brushSize, points: [{x:nx,y:ny}] };
  state.strokes.push(state.currentStroke);
  if (state.strokes.length > MAX_STROKES) state.strokes.shift();
}

export function extendStroke(nx, ny){
  if (!state.currentStroke) return startStroke(nx, ny);
  state.currentStroke.points.push({x:nx,y:ny});
  redrawDrawCanvas();
}

export function endStroke(){
  state.currentStroke = null;
}

export function undoStroke(){
  if (!state.strokes.length) return;
  state.strokes.pop();
  redrawDrawCanvas();
}

export function clearDrawing(){
  state.strokes = [];
  state.currentStroke = null;
  redrawDrawCanvas();
  showToast('تم مسح الرسم');
}

export function redrawDrawCanvas(){
  const rect = dom.videoContainer.getBoundingClientRect();
  const ctx = dom.drawCanvas.getContext('2d');
  ctx.clearRect(0, 0, rect.width, rect.height);
  ctx.lineCap = 'round';
  ctx.lineJoin = 'round';

  state.strokes.forEach(st=>{
    if (st.points.length < 2){
      if (st.points.length === 1){
        ctx.fillStyle = st.color;
        ctx.beginPath();
        ctx.arc(st.points[0].x * rect.width, st.points[0].y * rect.height, st.size / 2, 0, Math.PI * 2);
        ctx.fill();
      }
      return;
    }
    ctx.strokeStyle = st.color;
    ctx.lineWidth = st.size;
    ctx.beginPath();
    st.points.forEach((p, i)=>{
      const px = p.x * rect.width, py = p.y * rect.height;
      if (i === 0) ctx.moveTo(px, py); else ctx.lineTo(px, py);
    });
    ctx.stroke();
  });
}
