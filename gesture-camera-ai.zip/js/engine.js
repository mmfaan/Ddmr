// ============================================================
// engine.js — "قائد" التطبيق: حلقة العرض التي تعمل كل إطار.
// تُشغّل تتبّع اليد دائمًا، وكشف الأشياء فقط في وضع التعرّف،
// وتُدير آلة حالة الإيماءة (لتفعيل الإجراء مرة واحدة فقط) والمؤشر اللمسي
// ============================================================
import { dom } from './dom.js';
import { state } from './state.js';
import { GESTURE_META } from './config.js';
import { isAnyModalOpen, vibrate, getDisplayPoint } from './utils.js';
import { detectHands, drawSkeleton, clearSkeleton, classifyGesture } from './handTracking.js';
import { runDetection } from './objectDetection.js';
import { startStroke, extendStroke, endStroke, clearDrawing } from './drawing.js';
import { startCountdown, cancelCountdown, saveDrawing } from './capture.js';
import { setMode, toggleMode } from './ui.js';

const STABILITY_FRAMES = 4;
const ACTION_COOLDOWN = 1100;

export function startEngine(){
  if (!state.rafId) loop();
}
export function stopEngine(){
  if (state.rafId){ cancelAnimationFrame(state.rafId); state.rafId = null; }
}

function loop(){
  state.rafId = requestAnimationFrame(loop);
  if (!state.handLandmarker || dom.video.readyState < 2) return;
  if (dom.video.currentTime === state.lastVideoTime) return;
  state.lastVideoTime = dom.video.currentTime;

  const now = performance.now();
  const rect = dom.videoContainer.getBoundingClientRect();
  const lm = detectHands(now);

  if (lm){
    drawSkeleton(lm, rect);
    const raw = classifyGesture(lm);
    updateGestureState(raw);
    handleContinuous(lm, raw, rect);
  } else {
    clearSkeleton();
    if (state.wasPinching){ endStroke(); state.wasPinching = false; }
    updateGestureState('none');
    dom.cursorDot.classList.add('hidden');
  }

  if (state.mode === 'recognize'){
    runDetection(rect, now);
  }
}

/* ---------- آلة حالة الإيماءة: استقرار + تفعيل عند التغيّر فقط ---------- */
function updateGestureState(raw){
  if (raw === state.candidateGesture){ state.candidateCount++; }
  else { state.candidateGesture = raw; state.candidateCount = 1; }

  if (state.candidateCount >= STABILITY_FRAMES && state.stableGesture !== state.candidateGesture){
    const prev = state.stableGesture;
    state.stableGesture = state.candidateGesture;
    onGestureChanged(prev, state.stableGesture);
  }
}

function onGestureChanged(prev, curr){
  if (curr === 'none' || !GESTURE_META[curr]){
    dom.gestureBadge.classList.add('hidden');
  } else {
    dom.gestureIcon.textContent = GESTURE_META[curr].icon;
    dom.gestureLabel.textContent = GESTURE_META[curr].label;
    dom.gestureBadge.classList.remove('hidden');
  }

  if (isAnyModalOpen()) return;

  const now = performance.now();
  const canAct = (now - state.lastActionTime) > ACTION_COOLDOWN;

  if (curr === 'peace' && (state.mode === 'photo' || state.mode === 'recognize') && canAct && !state.countdownActive){
    startCountdown(); state.lastActionTime = now;
  } else if (curr === 'fist'){
    if (state.countdownActive){ cancelCountdown(); }
    else if (state.mode === 'draw' && canAct && state.strokes.length){ clearDrawing(); state.lastActionTime = now; }
  } else if (curr === 'openPalm' && canAct && !state.countdownActive){
    toggleMode(); state.lastActionTime = now;
  } else if (curr === 'thumbsUp' && state.mode === 'draw' && canAct && state.strokes.length){
    saveDrawing(); state.lastActionTime = now;
  }
}

/* ---------- كل إطار: المؤشر اللمسي + الرسم بالهواء ---------- */
function getHoveredControl(px, py){
  const el = document.elementFromPoint(px, py);
  return el ? el.closest('.gesture-hoverable') : null;
}

function handleContinuous(lm, raw, rect){
  const tip = getDisplayPoint(lm[8].x, lm[8].y, rect);
  const screenX = rect.left + tip.x, screenY = rect.top + tip.y;

  dom.cursorDot.style.left = screenX + 'px';
  dom.cursorDot.style.top = screenY + 'px';
  dom.cursorDot.classList.remove('hidden');
  dom.cursorDot.classList.toggle('pinching', raw === 'pinch');

  const hovered = getHoveredControl(screenX, screenY);
  document.querySelectorAll('.gesture-hover').forEach(e => e.classList.remove('gesture-hover'));

  if (raw === 'pinch'){
    if (hovered){
      hovered.classList.add('gesture-hover');
      if (!state.wasPinching){ hovered.click(); vibrate(12); }
      if (state.currentStroke){ endStroke(); }
    } else if (state.mode === 'draw' && !isAnyModalOpen()){
      const nx = tip.x / rect.width, ny = tip.y / rect.height;
      if (!state.wasPinching) startStroke(nx, ny); else extendStroke(nx, ny);
    }
    state.wasPinching = true;
  } else {
    if (state.wasPinching){ endStroke(); }
    state.wasPinching = false;
  }
}
