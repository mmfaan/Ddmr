// ============================================================
// dom.js — كل مراجع عناصر DOM في مكان واحد. أي وحدة تحتاج عنصرًا
// من الصفحة تستورد `dom` بدلًا من استدعاء getElementById بنفسها
// ============================================================
function $(id){ return document.getElementById(id); }

export const dom = {
  // شاشات البداية والتحميل والخطأ
  introScreen: $('introScreen'),
  startBtn: $('startBtn'),
  introHelpBtn: $('introHelpBtn'),
  skeletonHero: $('skeletonHero'),
  loadingScreen: $('loadingScreen'),
  loadingText: $('loadingText'),
  errorOverlay: $('errorOverlay'),
  errorTitle: $('errorTitle'),
  errorText: $('errorText'),
  retryBtn: $('retryBtn'),

  // التطبيق الرئيسي
  app: $('app'),
  videoContainer: $('videoContainer'),
  video: $('video'),
  skeletonCanvas: $('skeletonCanvas'),
  detectionCanvas: $('detectionCanvas'),
  drawCanvas: $('drawCanvas'),
  captureCanvas: $('captureCanvas'),
  flashOverlay: $('flashOverlay'),
  countdownOverlay: $('countdownOverlay'),
  countdownNum: $('countdownNum'),
  gestureBadge: $('gestureBadge'),
  gestureIcon: $('gestureIcon'),
  gestureLabel: $('gestureLabel'),
  detectionPanel: $('detectionPanel'),
  cursorDot: $('cursorDot'),

  // الشريط العلوي
  helpBtn: $('helpBtn'),
  photoModeBtn: $('photoModeBtn'),
  drawModeBtn: $('drawModeBtn'),
  recognizeModeBtn: $('recognizeModeBtn'),
  settingsBtn: $('settingsBtn'),

  // أشرطة التحكم السفلية
  photoControls: $('photoControls'),
  galleryBtn: $('galleryBtn'),
  shutterBtn: $('shutterBtn'),
  flipCameraBtn: $('flipCameraBtn'),

  drawControls: $('drawControls'),
  undoBtn: $('undoBtn'),
  colorSwatches: $('colorSwatches'),
  saveDrawBtn: $('saveDrawBtn'),

  recognizeControls: $('recognizeControls'),
  voiceToggleBtn: $('voiceToggleBtn'),
  recognizeShutterBtn: $('recognizeShutterBtn'),
  logBtn: $('logBtn'),

  // النوافذ المنبثقة
  helpModal: $('helpModal'),
  gestureGuideList: $('gestureGuideList'),

  settingsModal: $('settingsModal'),
  cameraSeg: $('cameraSeg'),
  mirrorSwitch: $('mirrorSwitch'),
  skeletonSwitch: $('skeletonSwitch'),
  mergeSwitch: $('mergeSwitch'),
  sensitivitySlider: $('sensitivitySlider'),
  brushSizeSlider: $('brushSizeSlider'),
  detectThresholdSlider: $('detectThresholdSlider'),

  galleryModal: $('galleryModal'),
  galleryGrid: $('galleryGrid'),

  logModal: $('logModal'),
  logStats: $('logStats'),
  logList: $('logList'),

  toast: $('toast')
};
