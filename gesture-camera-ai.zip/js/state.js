// ============================================================
// state.js — كائن حالة واحد مُشترَك بين كل الوحدات.
// الوحدات الأخرى تستورد `state` وتُعدّل خصائصه مباشرة
// (لا يُعاد تعيين الكائن نفسه أبدًا، فقط خصائصه الداخلية)
// ============================================================
export const state = {
  // الكاميرا
  stream: null,
  facingMode: 'user',

  // الوضع الحالي
  mode: 'photo', // 'photo' | 'draw' | 'recognize'

  // الإعدادات القابلة للتعديل من المستخدم
  settings: {
    mirror: true,
    skeleton: true,
    merge: true,
    sensitivity: 1.0,
    brushSize: 7,
    detectThreshold: 0.45,
    voiceEnabled: false
  },

  brushColor: '#FF8A3D',

  // نماذج الذكاء الاصطناعي المُحمَّلة
  handLandmarker: null,
  objectDetector: null,

  // حلقة العرض
  lastVideoTime: -1,
  rafId: null,

  // آلة حالة الإيماءة (لتفادي التذبذب وتفعيل الإجراء مرة واحدة فقط)
  candidateGesture: 'none',
  candidateCount: 0,
  stableGesture: 'none',
  lastActionTime: 0,
  wasPinching: false,

  // العدّ التنازلي لالتقاط الصورة
  countdownActive: false,
  countdownTimer: null,

  // الرسم بالهواء
  strokes: [],
  currentStroke: null,

  // المعرض
  gallery: [],

  // كشف الأشياء (وضع التعرّف)
  lastDetections: [],
  lastDetectionTime: 0,
  detectionLog: [],       // {name, nameAr, ts}
  lastSpokenNames: new Set()
};
