// ============================================================
// config.js — كل البيانات الثابتة المشتركة بين الوحدات
// لا تحتوي هذه الوحدة على أي حالة متغيّرة، فقط قيم وإعدادات
// ============================================================

// روابط نماذج MediaPipe (Google، مفتوحة المصدر — Apache-2.0)
// https://github.com/google-ai-edge/mediapipe
export const MODEL_URLS = {
  wasm: "https://cdn.jsdelivr.net/npm/@mediapipe/tasks-vision@0.10.14/wasm",
  handLandmarker: "https://storage.googleapis.com/mediapipe-models/hand_landmarker/hand_landmarker/float16/1/hand_landmarker.task",
  // عدّة روابط بديلة لنموذج كشف الأشياء (EfficientDet-Lite0 على مجموعة بيانات COCO
  // بـ 80 صنفًا). نجرّبها بالترتيب فإن فشل أحدها ننتقل للتالي تلقائيًا
  objectDetectorCandidates: [
    "https://storage.googleapis.com/mediapipe-models/object_detector/efficientdet_lite0/float16/1/efficientdet_lite0.tflite",
    "https://storage.googleapis.com/mediapipe-models/object_detector/efficientdet_lite0/int8/1/efficientdet_lite0.tflite"
  ]
};

export const MODES = ['photo', 'draw', 'recognize'];

export const COLORS = ['#FF8A3D', '#4DE8D4', '#F2EFE9', '#FF5C5C', '#8B7CF6', '#FFE066'];

// اتصالات نقاط اليد الـ21 (المعيار القياسي لدى MediaPipe Hand Landmarker)
export const HAND_CONNECTIONS = [
  [0,1],[1,2],[2,3],[3,4], [0,5],[5,6],[6,7],[7,8],
  [5,9],[9,10],[10,11],[11,12], [9,13],[13,14],[14,15],[15,16],
  [13,17],[17,18],[18,19],[19,20], [0,17]
];

// هندسة تخطيطية مبسّطة لليد (لأيقونات SVG فقط، وليست إحداثيات MediaPipe الحقيقية)
const FINGER_GEOM = {
  thumb:  {base:[32,72], up:[16,56], down:[26,66]},
  index:  {base:[38,58], up:[30,18], down:[34,46]},
  middle: {base:[50,54], up:[50,10], down:[50,42]},
  ring:   {base:[62,58], up:[70,18], down:[66,46]},
  pinky:  {base:[72,64], up:[86,30], down:[76,52]}
};

// يرسم SVG تخطيطي ليد بحسب الأصابع "المرفوعة" — يُستخدم في شاشة البداية ودليل الإيماءات
export function handDiagramSVG(state, activeColor){
  activeColor = activeColor || '#4DE8D4';
  let s = '<circle cx="50" cy="74" r="15" fill="none" stroke="rgba(242,239,233,.18)" stroke-width="2"/>';
  s += '<line x1="50" y1="92" x2="50" y2="80" stroke="rgba(242,239,233,.18)" stroke-width="3" stroke-linecap="round"/>';
  for (const name in FINGER_GEOM){
    const g = FINGER_GEOM[name];
    const up = !!state[name];
    const tip = up ? g.up : g.down;
    const color = up ? activeColor : 'rgba(169,167,158,.4)';
    s += `<line x1="${g.base[0]}" y1="${g.base[1]}" x2="${tip[0]}" y2="${tip[1]}" stroke="${color}" stroke-width="4.5" stroke-linecap="round"/>`;
    s += `<circle cx="${tip[0]}" cy="${tip[1]}" r="4.5" fill="${color}"/>`;
  }
  return s;
}

export const GESTURES_INFO = [
  { state:{thumb:false,index:true,middle:true,ring:false,pinky:false}, icon:'✌️', title:'علامة النصر', desc:'التقاط صورة (وضع الصورة/التعرّف)', color:'#FF8A3D' },
  { state:{thumb:false,index:false,middle:false,ring:false,pinky:false}, icon:'✊', title:'قبضة', desc:'مسح الرسم، أو إلغاء العدّ التنازلي', color:'#FF5C5C' },
  { state:{thumb:true,index:true,middle:true,ring:true,pinky:true}, icon:'🖐️', title:'كفّ مفتوح', desc:'التنقّل بين أوضاع صورة ← رسم ← تعرّف', color:'#4DE8D4' },
  { state:{thumb:true,index:false,middle:false,ring:false,pinky:false}, icon:'👍', title:'إبهام لأعلى', desc:'حفظ الرسم (وضع الرسم)', color:'#FFE066' },
  { state:{thumb:true,index:true,middle:false,ring:false,pinky:false}, icon:'🤏', title:'قرص (الإبهام + السبّابة)', desc:'ارسم بإصبعك، أو اضغط الأزرار عن بُعد', color:'#8B7CF6' },
  { state:{thumb:false,index:true,middle:false,ring:false,pinky:false}, icon:'☝️', title:'السبّابة فقط', desc:'تحريك المؤشر دون رسم', color:'#4DE8D4' }
];

export const GESTURE_META = {
  fist:      { icon:'✊',  label:'قبضة' },
  openPalm:  { icon:'🖐️', label:'كفّ مفتوح' },
  peace:     { icon:'✌️', label:'علامة النصر' },
  thumbsUp:  { icon:'👍', label:'إبهام لأعلى' },
  pinch:     { icon:'🤏', label:'قرص' },
  pointer:   { icon:'☝️', label:'إشارة' }
};

// ترجمة أصناف COCO الثمانين إلى العربية — نموذج EfficientDet-Lite0 مدرَّب عليها
export const COCO_LABELS_AR = {
  person:'شخص', bicycle:'دراجة هوائية', car:'سيارة', motorcycle:'دراجة نارية', airplane:'طائرة',
  bus:'حافلة', train:'قطار', truck:'شاحنة', boat:'قارب', 'traffic light':'إشارة مرور',
  'fire hydrant':'صنبور إطفاء', 'stop sign':'إشارة توقف', 'parking meter':'عدّاد وقوف', bench:'مقعد',
  bird:'طائر', cat:'قطة', dog:'كلب', horse:'حصان', sheep:'خروف', cow:'بقرة', elephant:'فيل',
  bear:'دب', zebra:'حمار وحشي', giraffe:'زرافة', backpack:'حقيبة ظهر', umbrella:'مظلة',
  handbag:'حقيبة يد', tie:'ربطة عنق', suitcase:'حقيبة سفر', frisbee:'فريزبي', skis:'زلاجات تزلج',
  snowboard:'لوح تزلج', 'sports ball':'كرة رياضية', kite:'طائرة ورقية', 'baseball bat':'مضرب بيسبول',
  'baseball glove':'قفاز بيسبول', skateboard:'لوح سكيت', surfboard:'لوح ركمجة', 'tennis racket':'مضرب تنس',
  bottle:'زجاجة', 'wine glass':'كأس نبيذ', cup:'كوب', fork:'شوكة', knife:'سكين', spoon:'ملعقة',
  bowl:'وعاء', banana:'موز', apple:'تفاح', sandwich:'ساندويتش', orange:'برتقال', broccoli:'بروكلي',
  carrot:'جزر', 'hot dog':'هوت دوغ', pizza:'بيتزا', donut:'دونات', cake:'كعكة', chair:'كرسي',
  couch:'أريكة', 'potted plant':'نبتة أصيص', bed:'سرير', 'dining table':'طاولة طعام', toilet:'مرحاض',
  tv:'تلفاز', laptop:'حاسوب محمول', mouse:'فأرة حاسوب', remote:'جهاز تحكم', keyboard:'لوحة مفاتيح',
  'cell phone':'هاتف', microwave:'مايكروويف', oven:'فرن', toaster:'محمّصة', sink:'مغسلة',
  refrigerator:'ثلاجة', book:'كتاب', clock:'ساعة', vase:'مزهرية', scissors:'مقص', 'teddy bear':'دبدوب',
  'hair drier':'مجفف شعر', toothbrush:'فرشاة أسنان'
};

export function arLabel(name){
  return COCO_LABELS_AR[name] || name;
}
