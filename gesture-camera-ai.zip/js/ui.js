// ============================================================
// ui.js — طبقة الربط: كل أزرار الواجهة، النوافذ المنبثقة، الإعدادات،
// والتنقّل بين الأوضاع الثلاثة (صورة / رسم / تعرّف)
// ============================================================
import { dom } from './dom.js';
import { state } from './state.js';
import { MODES, COLORS, GESTURES_INFO, handDiagramSVG } from './config.js';
import { showToast } from './utils.js';
import { startCamera, applyMirrorClass } from './camera.js';
import { undoStroke } from './drawing.js';
import { saveDrawing, startCountdown } from './capture.js';
import { clearDetectionCanvas, toggleVoice, renderLog, isAvailable as objectDetectorAvailable } from './objectDetection.js';

/* ---------- الأوضاع الثلاثة ---------- */
export function toggleMode(){
  const i = MODES.indexOf(state.mode);
  setMode(MODES[(i + 1) % MODES.length]);
}

export function setMode(next){
  if (next === 'recognize' && !objectDetectorAvailable()){
    showToast('ميزة التعرّف على الأشياء غير متاحة حاليًا');
    next = 'photo';
  }
  if (state.mode === 'recognize' && next !== 'recognize'){
    clearDetectionCanvas();
  }
  state.mode = next;

  document.body.classList.remove('mode-draw', 'mode-recognize');
  if (next === 'draw') document.body.classList.add('mode-draw');
  if (next === 'recognize') document.body.classList.add('mode-recognize');

  dom.photoModeBtn.classList.toggle('active', next === 'photo');
  dom.drawModeBtn.classList.toggle('active', next === 'draw');
  dom.recognizeModeBtn.classList.toggle('active', next === 'recognize');

  dom.photoControls.classList.toggle('hidden', next !== 'photo');
  dom.drawControls.classList.toggle('hidden', next !== 'draw');
  dom.recognizeControls.classList.toggle('hidden', next !== 'recognize');
}

/* ---------- دليل الإيماءات وهيكل شاشة البداية ---------- */
export function renderGestureGuide(){
  dom.gestureGuideList.innerHTML = GESTURES_INFO.map(g => `
    <div class="gesture-row">
      <svg class="gesture-diagram" viewBox="0 0 100 100">${handDiagramSVG(g.state, g.color)}</svg>
      <div class="gesture-copy"><b>${g.icon} ${g.title}</b><span>${g.desc}</span></div>
    </div>`).join('');
}

export function renderHeroSkeleton(){
  dom.skeletonHero.innerHTML = handDiagramSVG(
    { thumb:true, index:true, middle:true, ring:true, pinky:true }, '#4DE8D4'
  );
}

/* ---------- لوحة ألوان الرسم ---------- */
export function renderColorSwatches(){
  dom.colorSwatches.innerHTML = '';
  COLORS.forEach(c=>{
    const el = document.createElement('button');
    el.className = 'swatch gesture-hoverable' + (c === state.brushColor ? ' active' : '');
    el.style.background = c;
    el.dataset.color = c;
    el.addEventListener('click', ()=> setBrushColor(c));
    dom.colorSwatches.appendChild(el);
  });
  const customWrap = document.createElement('label');
  customWrap.className = 'swatch custom-swatch';
  customWrap.textContent = '+';
  const inp = document.createElement('input');
  inp.type = 'color';
  inp.value = state.brushColor;
  inp.addEventListener('input', (e)=> setBrushColor(e.target.value));
  customWrap.appendChild(inp);
  dom.colorSwatches.appendChild(customWrap);
}
function setBrushColor(c){
  state.brushColor = c;
  [...dom.colorSwatches.querySelectorAll('.swatch')].forEach(s => s.classList.toggle('active', s.dataset.color === c));
}

/* ---------- النوافذ المنبثقة ---------- */
function openModal(id){ document.getElementById(id).classList.remove('hidden'); }
function closeModal(id){ document.getElementById(id).classList.add('hidden'); }

/* ---------- ربط كل عناصر التحكم (يُستدعى مرة واحدة عند الإقلاع) ---------- */
export function initUI(){
  renderGestureGuide();
  renderHeroSkeleton();
  renderColorSwatches();

  dom.photoModeBtn.addEventListener('click', ()=> setMode('photo'));
  dom.drawModeBtn.addEventListener('click', ()=> setMode('draw'));
  dom.recognizeModeBtn.addEventListener('click', ()=> setMode('recognize'));

  dom.shutterBtn.addEventListener('click', ()=>{ if (!state.countdownActive) startCountdown(); });
  dom.recognizeShutterBtn.addEventListener('click', ()=>{ if (!state.countdownActive) startCountdown(); });

  dom.flipCameraBtn.addEventListener('click', async ()=>{
    const next = state.facingMode === 'user' ? 'environment' : 'user';
    try{ await startCamera(next); syncCameraSeg(); }
    catch(e){ showToast('تعذّر تبديل الكاميرا'); }
  });

  dom.undoBtn.addEventListener('click', undoStroke);
  dom.saveDrawBtn.addEventListener('click', ()=>{ state.strokes.length ? saveDrawing() : showToast('لا يوجد رسم بعد'); });

  dom.voiceToggleBtn.addEventListener('click', ()=>{
    const on = toggleVoice();
    showToast(on ? 'تم تفعيل النطق الصوتي' : 'تم إيقاف النطق الصوتي');
  });
  dom.logBtn.addEventListener('click', ()=>{ renderLog(); openModal('logModal'); });

  dom.galleryBtn.addEventListener('click', ()=> openModal('galleryModal'));
  dom.helpBtn.addEventListener('click', ()=> openModal('helpModal'));
  dom.settingsBtn.addEventListener('click', ()=> openModal('settingsModal'));
  dom.introHelpBtn.addEventListener('click', ()=> openModal('helpModal'));

  document.querySelectorAll('[data-close]').forEach(el=>{
    el.addEventListener('click', ()=> closeModal(el.dataset.close));
  });

  dom.mirrorSwitch.addEventListener('click', ()=>{
    state.settings.mirror = !state.settings.mirror;
    dom.mirrorSwitch.classList.toggle('on', state.settings.mirror);
    applyMirrorClass();
  });
  dom.skeletonSwitch.addEventListener('click', ()=>{
    state.settings.skeleton = !state.settings.skeleton;
    dom.skeletonSwitch.classList.toggle('on', state.settings.skeleton);
  });
  dom.mergeSwitch.addEventListener('click', ()=>{
    state.settings.merge = !state.settings.merge;
    dom.mergeSwitch.classList.toggle('on', state.settings.merge);
  });
  dom.sensitivitySlider.addEventListener('input', (e)=>{ state.settings.sensitivity = Number(e.target.value) / 100; });
  dom.brushSizeSlider.addEventListener('input', (e)=>{ state.settings.brushSize = Number(e.target.value); });
  dom.detectThresholdSlider.addEventListener('input', (e)=>{ state.settings.detectThreshold = Number(e.target.value) / 100; });

  dom.cameraSeg.addEventListener('click', async (e)=>{
    const btn = e.target.closest('.seg-btn');
    if (!btn || btn.dataset.facing === state.facingMode) return;
    try{ await startCamera(btn.dataset.facing); syncCameraSeg(); }
    catch(err){ showToast('تعذّر تبديل الكاميرا'); }
  });
}

function syncCameraSeg(){
  [...dom.cameraSeg.querySelectorAll('.seg-btn')].forEach(b =>
    b.classList.toggle('active', b.dataset.facing === state.facingMode)
  );
}
