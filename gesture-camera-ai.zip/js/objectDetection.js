// ============================================================
// objectDetection.js — التعرّف الحقيقي على الأشياء عبر شبكة عصبية
// مدرَّبة فعليًا (EfficientDet-Lite0 على مجموعة بيانات COCO، ٨٠ صنفًا)
// من MediaPipe Model Maker (Google، مفتوح المصدر). هذا نموذج تعلّم
// عميق حقيقي وليس مجرّد قواعد هندسية كإيماءات اليد
// ============================================================
import { ObjectDetector } from "https://cdn.jsdelivr.net/npm/@mediapipe/tasks-vision@0.10.14";
import { dom } from './dom.js';
import { state } from './state.js';
import { mapVideoPxToDisplay, formatTime } from './utils.js';
import { MODEL_URLS, arLabel } from './config.js';

const DETECTION_INTERVAL_MS = 350; // نُشغّل النموذج نحو 3 مرات/ثانية فقط (توفير أداء)
let lastTickNames = new Set();

export async function initObjectDetector(vision){
  const makeOptions = (url, delegate) => ({
    baseOptions: { modelAssetPath: url, delegate },
    scoreThreshold: 0.3, // حدّ أساسي منخفض؛ التصفية الفعلية تتم لاحقًا بحسب إعداد المستخدم
    maxResults: 10,
    runningMode: 'VIDEO'
  });

  for (const url of MODEL_URLS.objectDetectorCandidates){
    try{
      state.objectDetector = await ObjectDetector.createFromOptions(vision, makeOptions(url, 'GPU'));
      return;
    }catch(e){ console.warn('فشل تحميل نموذج كشف الأشياء (GPU):', url, e); }
  }
  try{
    state.objectDetector = await ObjectDetector.createFromOptions(
      vision, makeOptions(MODEL_URLS.objectDetectorCandidates[0], 'CPU')
    );
  }catch(e){
    console.warn('تعذّر تحميل نموذج كشف الأشياء نهائيًا — ميزة التعرّف ستكون معطّلة', e);
    state.objectDetector = null;
  }
}

export function isAvailable(){ return !!state.objectDetector; }

// يُستدعى كل إطار من محرّك العرض؛ يُشغّل النموذج الفعلي بمعدّل مُخفَّض فقط
export function runDetection(rect, timestampMs){
  if (!state.objectDetector) return;

  if (timestampMs - state.lastDetectionTime < DETECTION_INTERVAL_MS){
    drawDetections(state.lastDetections, rect); // نعيد رسم آخر نتيجة كي تبقى الصناديق ثابتة بين التحديثات
    return;
  }
  state.lastDetectionTime = timestampMs;

  const result = state.objectDetector.detectForVideo(dom.video, timestampMs);
  const filtered = (result.detections || []).filter(d=>
    d.categories && d.categories[0] && d.categories[0].score >= state.settings.detectThreshold
  );
  state.lastDetections = filtered;

  drawDetections(filtered, rect);
  updatePanel(filtered);
  logNewDetections(filtered);
  if (state.settings.voiceEnabled) narrate(filtered);
}

function hashHue(str){
  let h = 0;
  for (let i = 0; i < str.length; i++) h = (h * 31 + str.charCodeAt(i)) % 360;
  return h;
}

function drawDetections(detections, rect){
  const ctx = dom.detectionCanvas.getContext('2d');
  ctx.clearRect(0, 0, rect.width, rect.height);
  if (!detections.length) return;

  const vw = dom.video.videoWidth, vh = dom.video.videoHeight;
  const mirror = state.settings.mirror && state.facingMode === 'user';

  detections.forEach(det=>{
    const box = det.boundingBox;
    const tl = mapVideoPxToDisplay(box.originX, box.originY, vw, vh, rect.width, rect.height);
    const br = mapVideoPxToDisplay(box.originX + box.width, box.originY + box.height, vw, vh, rect.width, rect.height);
    let x = tl.x;
    const y = tl.y, w = br.x - tl.x, h = br.y - tl.y;
    if (mirror) x = rect.width - tl.x - w;

    const cat = det.categories[0];
    const label = arLabel(cat.categoryName);
    const pct = Math.round(cat.score * 100);
    const color = `hsl(${hashHue(cat.categoryName)}, 80%, 65%)`;

    ctx.strokeStyle = color;
    ctx.lineWidth = 2.5;
    ctx.strokeRect(x, y, w, h);

    const text = `${label} ${pct}%`;
    ctx.font = "600 13px 'IBM Plex Sans Arabic', sans-serif";
    const tw = ctx.measureText(text).width;
    const tagY = Math.max(0, y - 24);
    ctx.fillStyle = color;
    ctx.fillRect(x, tagY, tw + 16, 24);
    ctx.fillStyle = '#0B0D0C';
    ctx.textBaseline = 'middle';
    ctx.fillText(text, x + 8, tagY + 12);
  });
}

function updatePanel(detections){
  if (!detections.length){
    dom.detectionPanel.classList.add('hidden');
    dom.detectionPanel.innerHTML = '';
    return;
  }
  const byName = new Map();
  detections.forEach(d=>{
    const cat = d.categories[0];
    const prev = byName.get(cat.categoryName);
    if (!prev || cat.score > prev.score) byName.set(cat.categoryName, cat);
  });
  dom.detectionPanel.classList.remove('hidden');
  dom.detectionPanel.innerHTML = [...byName.values()].map(cat => `
    <div class="detection-chip"><b>${arLabel(cat.categoryName)}</b><span>${Math.round(cat.score * 100)}%</span></div>
  `).join('');
}

function logNewDetections(detections){
  const now = new Set(detections.map(d => d.categories[0].categoryName));
  now.forEach(name=>{
    if (!lastTickNames.has(name)){
      state.detectionLog.unshift({ name, nameAr: arLabel(name), ts: Date.now() });
      if (state.detectionLog.length > 150) state.detectionLog.pop();
    }
  });
  lastTickNames = now;
}

function narrate(detections){
  if (!('speechSynthesis' in window)) return;
  const now = new Set(detections.map(d => d.categories[0].categoryName));
  const newOnes = [...now].filter(n => !state.lastSpokenNames.has(n));
  state.lastSpokenNames = now;
  if (!newOnes.length) return;
  try{
    const utter = new SpeechSynthesisUtterance(newOnes.map(arLabel).join('، '));
    utter.lang = 'ar-SA';
    utter.rate = 1.05;
    speechSynthesis.speak(utter);
  }catch(e){}
}

export function toggleVoice(){
  state.settings.voiceEnabled = !state.settings.voiceEnabled;
  dom.voiceToggleBtn.classList.toggle('active-toggle', state.settings.voiceEnabled);
  if (!state.settings.voiceEnabled && 'speechSynthesis' in window){
    try{ speechSynthesis.cancel(); }catch(e){}
  }
  return state.settings.voiceEnabled;
}

export function clearDetectionCanvas(){
  const ctx = dom.detectionCanvas.getContext('2d');
  ctx.clearRect(0, 0, dom.detectionCanvas.width, dom.detectionCanvas.height);
  dom.detectionPanel.classList.add('hidden');
  dom.detectionPanel.innerHTML = '';
}

export function renderLog(){
  const log = state.detectionLog;
  const uniqueCount = new Set(log.map(e => e.nameAr)).size;
  dom.logStats.innerHTML = `
    <div class="log-stat"><b>${log.length}</b><span>إجمالي الأحداث</span></div>
    <div class="log-stat"><b>${uniqueCount}</b><span>أنواع مختلفة</span></div>
  `;
  if (!log.length){
    dom.logList.innerHTML = '<div id="logEmpty">لم يُسجَّل أي اكتشاف بعد. جرّب وضع 🔍 تعرّف.</div>';
    return;
  }
  dom.logList.innerHTML = log.slice(0, 60).map(e => `
    <div class="log-row"><span class="l-name">${e.nameAr}</span><span class="l-time">${formatTime(e.ts)}</span></div>
  `).join('');
}
