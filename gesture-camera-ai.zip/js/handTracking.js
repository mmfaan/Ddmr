// ============================================================
// handTracking.js — تتبّع اليد عبر MediaPipe Hand Landmarker
// (نموذج مفتوح المصدر من Google، 21 نقطة مفصلية لكل يد)
// وتصنيف الإيماءة اعتمادًا على استدلال هندسي من هذه النقاط
// ============================================================
import { HandLandmarker } from "https://cdn.jsdelivr.net/npm/@mediapipe/tasks-vision@0.10.14";
import { dom } from './dom.js';
import { state } from './state.js';
import { dist2D, getDisplayPoint } from './utils.js';
import { MODEL_URLS, HAND_CONNECTIONS } from './config.js';

export async function initHandLandmarker(vision){
  const base = { modelAssetPath: MODEL_URLS.handLandmarker };
  const common = {
    runningMode: 'VIDEO', numHands: 1,
    minHandDetectionConfidence: 0.55, minHandPresenceConfidence: 0.5, minTrackingConfidence: 0.5
  };
  try{
    state.handLandmarker = await HandLandmarker.createFromOptions(vision, {
      baseOptions: { ...base, delegate: 'GPU' }, ...common
    });
  }catch(e){
    console.warn('تعذّر استخدام GPU لتتبّع اليد، جارٍ المحاولة عبر CPU', e);
    state.handLandmarker = await HandLandmarker.createFromOptions(vision, {
      baseOptions: { ...base, delegate: 'CPU' }, ...common
    });
  }
}

// يُشغَّل مرة كل إطار: يعيد مصفوفة الـ21 نقطة لليد الأولى المكتشفة، أو null
export function detectHands(timestampMs){
  if (!state.handLandmarker) return null;
  const result = state.handLandmarker.detectForVideo(dom.video, timestampMs);
  if (result.landmarks && result.landmarks.length) return result.landmarks[0];
  return null;
}

export function drawSkeleton(lm, rect){
  const ctx = dom.skeletonCanvas.getContext('2d');
  ctx.clearRect(0, 0, rect.width, rect.height);
  if (!state.settings.skeleton) return;

  ctx.lineWidth = 3;
  ctx.strokeStyle = 'rgba(77,232,212,.85)';
  ctx.beginPath();
  HAND_CONNECTIONS.forEach(([a, b])=>{
    const pa = getDisplayPoint(lm[a].x, lm[a].y, rect);
    const pb = getDisplayPoint(lm[b].x, lm[b].y, rect);
    ctx.moveTo(pa.x, pa.y); ctx.lineTo(pb.x, pb.y);
  });
  ctx.stroke();

  lm.forEach((p, i)=>{
    const d = getDisplayPoint(p.x, p.y, rect);
    ctx.beginPath();
    ctx.arc(d.x, d.y, i === 8 ? 6 : 3.2, 0, Math.PI * 2);
    ctx.fillStyle = i === 8 ? '#FF8A3D' : 'rgba(242,239,233,.9)';
    ctx.fill();
  });
}

export function clearSkeleton(){
  const ctx = dom.skeletonCanvas.getContext('2d');
  ctx.clearRect(0, 0, dom.skeletonCanvas.width, dom.skeletonCanvas.height);
}

/* ---------- تصنيف الإيماءة ---------- */
function isFingerExtended(lm, tip, mcp, ratio){
  const wrist = lm[0];
  return dist2D(lm[tip], wrist) > dist2D(lm[mcp], wrist) * ratio;
}
function isThumbExtended(lm, ratio){
  const pinkyMcp = lm[17];
  return dist2D(lm[4], pinkyMcp) > dist2D(lm[2], pinkyMcp) * ratio;
}
function isPinching(lm, sensitivity){
  const handSize = dist2D(lm[0], lm[9]);
  const pinchDist = dist2D(lm[4], lm[8]);
  return (pinchDist / handSize) < (0.45 * sensitivity);
}

export function classifyGesture(lm){
  const s = state.settings.sensitivity;
  if (isPinching(lm, s)) return 'pinch';

  const idx = isFingerExtended(lm, 8, 5, 1.25 / s);
  const mid = isFingerExtended(lm, 12, 9, 1.25 / s);
  const ring = isFingerExtended(lm, 16, 13, 1.25 / s);
  const pinky = isFingerExtended(lm, 20, 17, 1.25 / s);
  const thumb = isThumbExtended(lm, 1.15 / s);

  if (idx && mid && !ring && !pinky) return 'peace';
  if (idx && !mid && !ring && !pinky) return 'pointer';
  if (!idx && !mid && !ring && !pinky){
    if (thumb && lm[4].y < lm[0].y - 0.05) return 'thumbsUp';
    return 'fist';
  }
  if (idx && mid && ring && pinky) return 'openPalm';
  return 'none';
}
