// ============================================================
// capture.js — العدّ التنازلي، التقاط الصورة (مع دمج طبقة الرسم أو
// طبقة وسوم التعرّف بحسب الوضع الحالي)، وحفظ الرسم بمفرده
// ============================================================
import { dom } from './dom.js';
import { state } from './state.js';
import { showToast, vibrate } from './utils.js';
import { addToGallery } from './gallery.js';

export function startCountdown(){
  state.countdownActive = true;
  dom.countdownOverlay.classList.remove('hidden');
  let n = 3;
  dom.countdownNum.textContent = n;
  beep();
  state.countdownTimer = setInterval(()=>{
    n--;
    if (n <= 0){
      clearInterval(state.countdownTimer);
      state.countdownActive = false;
      dom.countdownOverlay.classList.add('hidden');
      capturePhoto();
    } else {
      dom.countdownNum.textContent = n;
      beep();
    }
  }, 800);
}

export function cancelCountdown(){
  clearInterval(state.countdownTimer);
  state.countdownActive = false;
  dom.countdownOverlay.classList.add('hidden');
  showToast('تم الإلغاء');
}

export function capturePhoto(){
  const rect = dom.videoContainer.getBoundingClientRect();
  const containerAspect = rect.width / rect.height;
  const longSide = 1440;
  let outW, outH;
  if (containerAspect >= 1){ outW = longSide; outH = Math.round(longSide / containerAspect); }
  else { outH = longSide; outW = Math.round(longSide * containerAspect); }

  dom.captureCanvas.width = outW;
  dom.captureCanvas.height = outH;
  const ctx = dom.captureCanvas.getContext('2d');

  const vw = dom.video.videoWidth, vh = dom.video.videoHeight;
  const videoAspect = vw / vh;
  let sx, sy, sw, sh;
  if (videoAspect > containerAspect){ sh = vh; sw = sh * containerAspect; sx = (vw - sw) / 2; sy = 0; }
  else { sw = vw; sh = sw / containerAspect; sx = 0; sy = (vh - sh) / 2; }

  // الفيديو يُعكَس هنا يدويًا لأن قناتي الرسم والتعرّف مخزَّنتان أصلًا
  // في "فضاء المرآة" (عبر getDisplayPoint)، فتبقى الطبقات متطابقة
  const mirror = state.settings.mirror && state.facingMode === 'user';
  ctx.save();
  if (mirror){ ctx.translate(outW, 0); ctx.scale(-1, 1); }
  ctx.drawImage(dom.video, sx, sy, sw, sh, 0, 0, outW, outH);
  ctx.restore();

  let kind = 'photo';
  if (state.settings.merge && state.mode === 'draw' && state.strokes.length){
    ctx.drawImage(dom.drawCanvas, 0, 0, outW, outH);
    kind = 'drawing';
  } else if (state.settings.merge && state.mode === 'recognize' && state.lastDetections.length){
    ctx.drawImage(dom.detectionCanvas, 0, 0, outW, outH);
    kind = 'recognize';
  }

  dom.flashOverlay.classList.remove('flash-anim');
  void dom.flashOverlay.offsetWidth;
  dom.flashOverlay.classList.add('flash-anim');
  vibrate([20, 30, 20]);

  addToGallery(dom.captureCanvas.toDataURL('image/jpeg', 0.92), kind);
  showToast('تم حفظ الصورة');
}

export function saveDrawing(){
  const rect = dom.videoContainer.getBoundingClientRect();
  dom.captureCanvas.width = Math.round(rect.width);
  dom.captureCanvas.height = Math.round(rect.height);
  const ctx = dom.captureCanvas.getContext('2d');
  ctx.clearRect(0, 0, dom.captureCanvas.width, dom.captureCanvas.height);
  ctx.drawImage(dom.drawCanvas, 0, 0, dom.captureCanvas.width, dom.captureCanvas.height);
  addToGallery(dom.captureCanvas.toDataURL('image/png'), 'drawing');
  vibrate(25);
  showToast('تم حفظ الرسم');
}

export function beep(){
  try{
    const Ctx = window.AudioContext || window.webkitAudioContext;
    const ctx = new Ctx();
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.frequency.value = 720;
    gain.gain.setValueAtTime(0.08, ctx.currentTime);
    gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.15);
    osc.connect(gain); gain.connect(ctx.destination);
    osc.start(); osc.stop(ctx.currentTime + 0.15);
  }catch(e){}
}
